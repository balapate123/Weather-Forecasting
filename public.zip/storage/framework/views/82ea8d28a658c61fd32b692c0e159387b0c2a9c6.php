<?php
	use Session;
	Session::get('email')
	$request->session()->flush();
	return redirect('Admin/');
?>