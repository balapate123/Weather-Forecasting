<header id="header" class="header_area">
	<nav class="navbar">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="nav-btn navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="brand"><img src="<?php echo e(url('public/img/accu.png')); ?>" alt="Accu Weather" style="height:150px;"></a>
			</div>
			<div id="navbar" class="collapse navbar-collapse navbar-right">
				<ul class="nav navbar-nav nav-menu">
					<!--<li class="active"><a data-scroll href="#home">Home <span class="sr-only">(current)</span></a></li>
					<li><a data-scroll href="#location">Map</a></li>
					<li><a data-scroll href="#statistics">Statistics</a></li>
					<li><a data-scroll href="#testimonial">Testimonial</a></li>
					<li><a data-scroll href="#download">Download</a></li>
					<li><a data-scroll href="#subscribe">Subscribe</a></li>-->
				</ul>
			</div><!--/.navbar-collapse -->
		</div>
	</nav><!-- Navigation Bar -->
</header><!-- Header -->